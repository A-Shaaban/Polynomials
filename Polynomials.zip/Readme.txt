This is a software developed using basic programming language for making all the basic operations 
on any polynomial function of any degree including plotting the function and its derivative and its integral,
getting the roots, inflection points and calcualte the area under the curve.
This was developed as a self work in my first year in college.